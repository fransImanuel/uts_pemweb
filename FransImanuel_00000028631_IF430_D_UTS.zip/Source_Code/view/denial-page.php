<?php include('header.php'); ?>
<!DOCTYPE html>
<body>
<!-- -------------------------------------------content--------------------------------------------------- -->
    <section id="home-denial">
        <div class="center-border">
            <img src="../assets/Misc/home-denial.svg" alt="">
            <p>You Need To Login First</p>
        </div>
    </section>
    <!-- ------------------------------------------------footer--------------------------------------------------- -->
   
    <?php
        include('footer.php');
    ?>
</body>
</html>