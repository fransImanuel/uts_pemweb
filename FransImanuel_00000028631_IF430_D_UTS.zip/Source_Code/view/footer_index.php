<footer>
    <div class="quareter-circle"></div>
        <h1 class="title">Contact Us</h1>
        <img src="assets/Misc/circle-footer.png" alt="">
        <p id="baris-1">
            <li>
                <a href=""><i class="fab fa-facebook-square fa-2x"></i></a>
                <a href=""><i class="fab fa-instagram  fa-2x"></i></a>
                <a href=""><i class="fab fa-twitter-square  fa-2x"></i></a>
            </li>
        </p>
        <div id="baris-2">
            <li><a href="#">Help Center</a></li>
            <li><a href="#">Terms</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Cookies</a></li>
            <li><a href="#">Ads Info</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Status</a></li>
            <li><a href="#">Jobs</a></li>
            <li><a href="#">Brands</a></li>
            <li><a href="#">Advertise</a></li>
            <li><a href="#">Marketing</a></li>
            <li><a href="#">Businesess</a></li>
            <li><a href="#">Developers</a></li>
            <li><a href="#">Directory</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">&copy;Umedia, Inc</a></li>
        </div>           
</footer>