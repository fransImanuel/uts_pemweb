<?php
    $host = "localhost";
    $db_name = "umedia";
    $username = "root";
    $password = "";
    $connect = new PDO("mysql:host=$host;dbname=$db_name;",$username,$password);
?>